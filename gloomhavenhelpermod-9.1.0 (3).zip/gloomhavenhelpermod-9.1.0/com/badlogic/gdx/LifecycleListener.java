package com.badlogic.gdx;

public interface LifecycleListener {
   void pause();

   void resume();

   void dispose();
}
