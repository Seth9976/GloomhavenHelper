package com.badlogic.gdx.backends.lwjgl3.audio.mock;

import com.badlogic.gdx.audio.AudioRecorder;

public class MockAudioRecorder implements AudioRecorder {
   @Override
   public void read(short[] samples, int offset, int numSamples) {
   }

   @Override
   public void dispose() {
   }
}
