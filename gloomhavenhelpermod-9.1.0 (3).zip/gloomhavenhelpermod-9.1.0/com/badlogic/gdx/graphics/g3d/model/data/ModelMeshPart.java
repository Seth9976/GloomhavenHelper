package com.badlogic.gdx.graphics.g3d.model.data;

public class ModelMeshPart {
   public String id;
   public short[] indices;
   public int primitiveType;
}
