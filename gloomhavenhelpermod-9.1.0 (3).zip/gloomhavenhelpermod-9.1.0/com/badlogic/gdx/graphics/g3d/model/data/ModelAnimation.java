package com.badlogic.gdx.graphics.g3d.model.data;

import com.badlogic.gdx.utils.Array;

public class ModelAnimation {
   public String id;
   public Array nodeAnimations = new Array();
}
