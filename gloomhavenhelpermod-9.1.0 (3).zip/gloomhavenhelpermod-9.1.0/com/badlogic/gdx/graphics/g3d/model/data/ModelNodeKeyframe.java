package com.badlogic.gdx.graphics.g3d.model.data;

public class ModelNodeKeyframe {
   public float keytime;
   public Object value = null;
}
