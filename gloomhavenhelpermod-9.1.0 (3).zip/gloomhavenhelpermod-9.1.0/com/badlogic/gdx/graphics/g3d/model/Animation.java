package com.badlogic.gdx.graphics.g3d.model;

import com.badlogic.gdx.utils.Array;

public class Animation {
   public String id;
   public float duration;
   public Array nodeAnimations = new Array();
}
