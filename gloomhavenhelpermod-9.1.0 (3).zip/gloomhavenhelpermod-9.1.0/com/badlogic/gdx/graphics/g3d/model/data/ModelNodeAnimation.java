package com.badlogic.gdx.graphics.g3d.model.data;

import com.badlogic.gdx.utils.Array;

public class ModelNodeAnimation {
   public String nodeId;
   public Array translation;
   public Array rotation;
   public Array scaling;
}
