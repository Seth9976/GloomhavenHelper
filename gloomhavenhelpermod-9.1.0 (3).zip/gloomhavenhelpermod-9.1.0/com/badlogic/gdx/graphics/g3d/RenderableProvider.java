package com.badlogic.gdx.graphics.g3d;

import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.Pool;

public interface RenderableProvider {
   void getRenderables(Array var1, Pool var2);
}
