package com.badlogic.gdx.graphics.glutils;

public enum HdpiMode {
   Logical,
   Pixels;
}
