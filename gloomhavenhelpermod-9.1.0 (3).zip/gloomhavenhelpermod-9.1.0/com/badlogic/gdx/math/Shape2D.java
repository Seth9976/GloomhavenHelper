package com.badlogic.gdx.math;

public interface Shape2D {
   boolean contains(Vector2 var1);

   boolean contains(float var1, float var2);
}
