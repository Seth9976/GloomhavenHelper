package com.badlogic.gdx.scenes.scene2d;

public enum Touchable {
   enabled,
   disabled,
   childrenOnly;
}
