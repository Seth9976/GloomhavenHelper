package com.badlogic.gdx.scenes.scene2d.utils;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Null;

public interface Cullable {
   void setCullingArea(@Null Rectangle var1);
}
