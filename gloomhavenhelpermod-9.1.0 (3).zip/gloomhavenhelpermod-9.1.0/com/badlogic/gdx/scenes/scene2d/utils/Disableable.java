package com.badlogic.gdx.scenes.scene2d.utils;

public interface Disableable {
   void setDisabled(boolean var1);

   boolean isDisabled();
}
