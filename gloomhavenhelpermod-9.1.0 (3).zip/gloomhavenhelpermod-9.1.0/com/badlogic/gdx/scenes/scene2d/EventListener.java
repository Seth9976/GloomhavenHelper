package com.badlogic.gdx.scenes.scene2d;

public interface EventListener {
   boolean handle(Event var1);
}
