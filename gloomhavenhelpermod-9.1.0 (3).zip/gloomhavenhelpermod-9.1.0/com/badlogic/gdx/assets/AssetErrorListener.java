package com.badlogic.gdx.assets;

public interface AssetErrorListener {
   void error(AssetDescriptor var1, Throwable var2);
}
