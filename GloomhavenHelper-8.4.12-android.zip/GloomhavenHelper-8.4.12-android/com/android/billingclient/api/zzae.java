package com.android.billingclient.api;

import java.util.concurrent.Callable;

public final class zzae implements Callable {
    public final zzaf zza;

    public zzae(zzaf zzaf0) {
        this.zza = zzaf0;
    }

    @Override
    public final Object call() {
        this.zza.zza();
        return null;
    }
}

