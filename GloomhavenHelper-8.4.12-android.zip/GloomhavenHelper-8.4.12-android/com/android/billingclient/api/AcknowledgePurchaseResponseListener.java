package com.android.billingclient.api;

import androidx.annotation.NonNull;

public interface AcknowledgePurchaseResponseListener {
    void onAcknowledgePurchaseResponse(@NonNull BillingResult arg1);
}

