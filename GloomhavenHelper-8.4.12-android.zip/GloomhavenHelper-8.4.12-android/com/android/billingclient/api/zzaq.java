package com.android.billingclient.api;

public class zzaq {
    private final String zza;

    zzaq(String s, String s1, zzao zzao0) {
        this.zza = s;
    }

    public final String zza() {
        return this.zza;
    }
}

