package com.android.billingclient.api;

public final class zzad implements Runnable {
    public final zzaf zza;

    public zzad(zzaf zzaf0) {
        this.zza = zzaf0;
    }

    @Override
    public final void run() {
        this.zza.zzb();
    }
}

