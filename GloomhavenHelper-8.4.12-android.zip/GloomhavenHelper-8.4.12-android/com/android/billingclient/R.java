package com.android.billingclient;

public final class R {
}

