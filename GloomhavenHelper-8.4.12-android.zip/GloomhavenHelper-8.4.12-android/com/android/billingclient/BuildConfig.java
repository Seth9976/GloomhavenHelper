package com.android.billingclient;

import androidx.annotation.NonNull;

public final class BuildConfig {
    @NonNull
    public static final String APPLICATION_ID = "com.android.billingclient";
    @NonNull
    public static final String VERSION_NAME = "4.0.0";

}

