package com.badlogic.gdx.assets;

public interface AssetErrorListener {
    void error(AssetDescriptor arg1, Throwable arg2);
}

