package androidx.core.text;

public interface TextDirectionHeuristicCompat {
    boolean isRtl(CharSequence arg1, int arg2, int arg3);

    boolean isRtl(char[] arg1, int arg2, int arg3);
}

