package androidx.core.util;

public interface Consumer {
    void accept(Object arg1);
}

