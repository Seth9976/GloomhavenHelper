package androidx.lifecycle;

import androidx.annotation.RestrictTo.Scope;
import androidx.annotation.RestrictTo;

@RestrictTo({Scope.LIBRARY_GROUP})
public interface GeneratedAdapter {
    void callMethods(LifecycleOwner arg1, Event arg2, boolean arg3, MethodCallsLogger arg4);
}

