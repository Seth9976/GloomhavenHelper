package androidx.lifecycle;

public interface Observer {
    void onChanged(Object arg1);
}

