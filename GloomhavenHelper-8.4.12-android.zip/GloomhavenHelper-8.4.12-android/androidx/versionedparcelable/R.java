package androidx.versionedparcelable;

public final class R {
}

