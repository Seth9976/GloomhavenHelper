package androidx.localbroadcastmanager;

public final class R {
}

