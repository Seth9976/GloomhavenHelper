package androidx.coordinatorlayout;

public final class R {
    public static final class attr {
        public static final int alpha = 0x7F010003;  // attr:alpha
        public static final int coordinatorLayoutStyle = 0x7F010004;  // attr:coordinatorLayoutStyle
        public static final int font = 0x7F010005;  // attr:font
        public static final int fontProviderAuthority = 0x7F010006;  // attr:fontProviderAuthority
        public static final int fontProviderCerts = 0x7F010007;  // attr:fontProviderCerts
        public static final int fontProviderFetchStrategy = 0x7F010008;  // attr:fontProviderFetchStrategy
        public static final int fontProviderFetchTimeout = 0x7F010009;  // attr:fontProviderFetchTimeout
        public static final int fontProviderPackage = 0x7F01000A;  // attr:fontProviderPackage
        public static final int fontProviderQuery = 0x7F01000B;  // attr:fontProviderQuery
        public static final int fontStyle = 0x7F01000C;  // attr:fontStyle
        public static final int fontVariationSettings = 0x7F01000D;  // attr:fontVariationSettings
        public static final int fontWeight = 0x7F01000E;  // attr:fontWeight
        public static final int keylines = 0x7F01000F;  // attr:keylines
        public static final int layout_anchor = 0x7F010010;  // attr:layout_anchor
        public static final int layout_anchorGravity = 0x7F010011;  // attr:layout_anchorGravity
        public static final int layout_behavior = 0x7F010012;  // attr:layout_behavior
        public static final int layout_dodgeInsetEdges = 0x7F010013;  // attr:layout_dodgeInsetEdges
        public static final int layout_insetEdge = 0x7F010014;  // attr:layout_insetEdge
        public static final int layout_keyline = 0x7F010015;  // attr:layout_keyline
        public static final int statusBarBackground = 0x7F010016;  // attr:statusBarBackground
        public static final int ttcIndex = 0x7F010017;  // attr:ttcIndex

    }

    public static final class color {
        public static final int notification_action_color_filter = 0x7F020004;  // color:notification_action_color_filter
        public static final int notification_icon_bg_color = 0x7F020005;  // color:notification_icon_bg_color
        public static final int ripple_material_light = 0x7F020006;  // color:ripple_material_light
        public static final int secondary_text_default_material_light = 0x7F020007;  // color:secondary_text_default_material_light

    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 0x7F030002;  // dimen:compat_button_inset_horizontal_material
        public static final int compat_button_inset_vertical_material = 0x7F030003;  // dimen:compat_button_inset_vertical_material
        public static final int compat_button_padding_horizontal_material = 0x7F030004;  // dimen:compat_button_padding_horizontal_material
        public static final int compat_button_padding_vertical_material = 0x7F030005;  // dimen:compat_button_padding_vertical_material
        public static final int compat_control_corner_material = 0x7F030006;  // dimen:compat_control_corner_material
        public static final int compat_notification_large_icon_max_height = 0x7F030007;  // dimen:compat_notification_large_icon_max_height
        public static final int compat_notification_large_icon_max_width = 0x7F030008;  // dimen:compat_notification_large_icon_max_width
        public static final int notification_action_icon_size = 0x7F030009;  // dimen:notification_action_icon_size
        public static final int notification_action_text_size = 0x7F03000A;  // dimen:notification_action_text_size
        public static final int notification_big_circle_margin = 0x7F03000B;  // dimen:notification_big_circle_margin
        public static final int notification_content_margin_start = 0x7F03000C;  // dimen:notification_content_margin_start
        public static final int notification_large_icon_height = 0x7F03000D;  // dimen:notification_large_icon_height
        public static final int notification_large_icon_width = 0x7F03000E;  // dimen:notification_large_icon_width
        public static final int notification_main_column_padding_top = 0x7F03000F;  // dimen:notification_main_column_padding_top
        public static final int notification_media_narrow_margin = 0x7F030010;  // dimen:notification_media_narrow_margin
        public static final int notification_right_icon_size = 0x7F030011;  // dimen:notification_right_icon_size
        public static final int notification_right_side_padding_top = 0x7F030012;  // dimen:notification_right_side_padding_top
        public static final int notification_small_icon_background_padding = 0x7F030013;  // dimen:notification_small_icon_background_padding
        public static final int notification_small_icon_size_as_large = 0x7F030014;  // dimen:notification_small_icon_size_as_large
        public static final int notification_subtext_size = 0x7F030015;  // dimen:notification_subtext_size
        public static final int notification_top_pad = 0x7F030016;  // dimen:notification_top_pad
        public static final int notification_top_pad_large_text = 0x7F030017;  // dimen:notification_top_pad_large_text

    }

    public static final class drawable {
        public static final int notification_action_background = 0x7F040001;  // drawable:notification_action_background
        public static final int notification_bg = 0x7F040002;  // drawable:notification_bg
        public static final int notification_bg_low = 0x7F040003;  // drawable:notification_bg_low
        public static final int notification_bg_low_normal = 0x7F040004;  // drawable:notification_bg_low_normal
        public static final int notification_bg_low_pressed = 0x7F040005;  // drawable:notification_bg_low_pressed
        public static final int notification_bg_normal = 0x7F040006;  // drawable:notification_bg_normal
        public static final int notification_bg_normal_pressed = 0x7F040007;  // drawable:notification_bg_normal_pressed
        public static final int notification_icon_background = 0x7F040008;  // drawable:notification_icon_background
        public static final int notification_template_icon_bg = 0x7F040009;  // drawable:notification_template_icon_bg
        public static final int notification_template_icon_low_bg = 0x7F04000A;  // drawable:notification_template_icon_low_bg
        public static final int notification_tile_bg = 0x7F04000B;  // drawable:notification_tile_bg
        public static final int notify_panel_notification_icon_bg = 0x7F04000C;  // drawable:notify_panel_notification_icon_bg

    }

    public static final class id {
        public static final int action_container = 0x7F050000;  // id:action_container
        public static final int action_divider = 0x7F050001;  // id:action_divider
        public static final int action_image = 0x7F050002;  // id:action_image
        public static final int action_text = 0x7F050003;  // id:action_text
        public static final int actions = 0x7F050004;  // id:actions
        public static final int async = 0x7F050006;  // id:async
        public static final int blocking = 0x7F050007;  // id:blocking
        public static final int bottom = 0x7F050008;  // id:bottom
        public static final int chronometer = 0x7F050011;  // id:chronometer
        public static final int end = 0x7F050014;  // id:end
        public static final int forever = 0x7F050018;  // id:forever
        public static final int icon = 0x7F050019;  // id:icon
        public static final int icon_group = 0x7F05001A;  // id:icon_group
        public static final int info = 0x7F05001B;  // id:info
        public static final int italic = 0x7F05001C;  // id:italic
        public static final int left = 0x7F05001D;  // id:left
        public static final int line1 = 0x7F05001E;  // id:line1
        public static final int line3 = 0x7F05001F;  // id:line3
        public static final int none = 0x7F050020;  // id:none
        public static final int normal = 0x7F050021;  // id:normal
        public static final int notification_background = 0x7F050022;  // id:notification_background
        public static final int notification_main_column = 0x7F050023;  // id:notification_main_column
        public static final int notification_main_column_container = 0x7F050024;  // id:notification_main_column_container
        public static final int right = 0x7F050025;  // id:right
        public static final int right_icon = 0x7F050026;  // id:right_icon
        public static final int right_side = 0x7F050027;  // id:right_side
        public static final int start = 0x7F050028;  // id:start
        public static final int tag_transition_group = 0x7F050029;  // id:tag_transition_group
        public static final int tag_unhandled_key_event_manager = 0x7F05002A;  // id:tag_unhandled_key_event_manager
        public static final int tag_unhandled_key_listeners = 0x7F05002B;  // id:tag_unhandled_key_listeners
        public static final int text = 0x7F05002C;  // id:text
        public static final int text2 = 0x7F05002D;  // id:text2
        public static final int time = 0x7F05002E;  // id:time
        public static final int title = 0x7F05002F;  // id:title
        public static final int top = 0x7F050030;  // id:top

    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 0x7F060001;  // integer:status_bar_notification_info_maxnum

    }

    public static final class layout {
        public static final int notification_action = 0x7F070002;  // layout:notification_action
        public static final int notification_action_tombstone = 0x7F070003;  // layout:notification_action_tombstone
        public static final int notification_template_custom_big = 0x7F070004;  // layout:notification_template_custom_big
        public static final int notification_template_icon_group = 0x7F070005;  // layout:notification_template_icon_group
        public static final int notification_template_part_chronometer = 0x7F070006;  // layout:notification_template_part_chronometer
        public static final int notification_template_part_time = 0x7F070007;  // layout:notification_template_part_time

    }

    public static final class string {
        public static final int status_bar_notification_info_overflow = 0x7F080009;  // string:status_bar_notification_info_overflow "999+"

    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 0x7F090001;  // style:TextAppearance.Compat.Notification
        public static final int TextAppearance_Compat_Notification_Info = 0x7F090002;  // style:TextAppearance.Compat.Notification.Info
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7F090003;  // style:TextAppearance.Compat.Notification.Line2
        public static final int TextAppearance_Compat_Notification_Time = 0x7F090004;  // style:TextAppearance.Compat.Notification.Time
        public static final int TextAppearance_Compat_Notification_Title = 0x7F090005;  // style:TextAppearance.Compat.Notification.Title
        public static final int Widget_Compat_NotificationActionContainer = 0x7F090007;  // style:Widget.Compat.NotificationActionContainer
        public static final int Widget_Compat_NotificationActionText = 0x7F090008;  // style:Widget.Compat.NotificationActionText
        public static final int Widget_Support_CoordinatorLayout = 0x7F090009;  // style:Widget.Support.CoordinatorLayout

    }

    public static final class styleable {
        public static final int[] ColorStateListItem = null;
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] CoordinatorLayout = null;
        public static final int[] CoordinatorLayout_Layout = null;
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static final int CoordinatorLayout_Layout_layout_anchor = 1;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static final int CoordinatorLayout_Layout_layout_behavior = 3;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static final int CoordinatorLayout_Layout_layout_keyline = 6;
        public static final int CoordinatorLayout_keylines = 0;
        public static final int CoordinatorLayout_statusBarBackground = 1;
        public static final int[] FontFamily = null;
        public static final int[] FontFamilyFont = null;
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] GradientColor = null;
        public static final int[] GradientColorItem = null;
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;

        static {
            styleable.ColorStateListItem = new int[]{0x10101A5, 0x101031F, 0x7F010003};  // attr:alpha
            styleable.CoordinatorLayout = new int[]{0x7F01000F, 0x7F010016};  // attr:keylines
            styleable.CoordinatorLayout_Layout = new int[]{0x10100B3, 0x7F010010, 0x7F010011, 0x7F010012, 0x7F010013, 0x7F010014, 0x7F010015};  // attr:layout_anchor
            styleable.FontFamily = new int[]{0x7F010006, 0x7F010007, 0x7F010008, 0x7F010009, 0x7F01000A, 0x7F01000B};  // attr:fontProviderAuthority
            styleable.FontFamilyFont = new int[]{0x1010532, 0x1010533, 0x101053F, 0x101056F, 0x1010570, 0x7F010005, 0x7F01000C, 0x7F01000D, 0x7F01000E, 0x7F010017};  // attr:font
            styleable.GradientColor = new int[]{0x101019D, 0x101019E, 0x10101A1, 0x10101A2, 0x10101A3, 0x10101A4, 0x1010201, 0x101020B, 0x1010510, 0x1010511, 0x1010512, 0x1010513};
            styleable.GradientColorItem = new int[]{0x10101A5, 0x1010514};
        }
    }

}

